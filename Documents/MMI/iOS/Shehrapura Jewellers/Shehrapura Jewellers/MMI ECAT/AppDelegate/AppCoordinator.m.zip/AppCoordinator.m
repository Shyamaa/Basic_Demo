//
//  AppCoordinator.m
//  Jewel Desk
//
//  Created by MMI Softwares Pvt Ltd on 23/08/25.
//  Copyright © 2025 MMI Softwares. All rights reserved.
//

#import "AppCoordinator.h"
#import "Constants.h"

#import "LoginVC.h"
#import "HomeVC.h"
#import "MMIHOMEPanel.h"
#import "MainActivity.h"
#import "Gautom_HomeVC.h"
#import "MCX_RATE.h"
#import "SWRevealViewController.h"
#import "RearViewController.h"

@interface AppCoordinator ()
@property (nonatomic, strong) UIWindow *window;
@property (nonatomic, strong) UIStoryboard *storyboard;
@end

@implementation AppCoordinator

- (instancetype)initWithWindow:(UIWindow *)window {
    self = [super init];
    if (self) {
        self.window = window;
        self.storyboard = [UIStoryboard storyboardWithName:kStoryboardMain bundle:nil];
    }
    return self;
}

- (void)start {
    UIViewController *frontVC = [self determineFrontViewController];
    UINavigationController *frontNav = [[UINavigationController alloc] initWithRootViewController:frontVC];
    
    // Optional: SWRevealViewController
    RearViewController *rearVC = [[RearViewController alloc] init];
    UINavigationController *rearNav = [[UINavigationController alloc] initWithRootViewController:rearVC];
    
    SWRevealViewController *revealVC = [[SWRevealViewController alloc] initWithRearViewController:rearNav frontViewController:frontNav];
    
    self.window.rootViewController = revealVC;
    [self.window makeKeyAndVisible];
}

- (UIViewController *)determineFrontViewController {
    NSString *appType = [[NSUserDefaults standardUserDefaults] stringForKey:kAppTypeKey];
    NSString *mobile = [[NSUserDefaults standardUserDefaults] stringForKey:kUserMobileKey];
    NSString *template = [[NSUserDefaults standardUserDefaults] stringForKey:kUserTemplateKey];
    NSString *mcxRate = [[NSUserDefaults standardUserDefaults] stringForKey:kAppTypeMCX];
    
    if ([appType isEqualToString:@"3"]) {
        if (mobile == nil) {
            return [self vcWithID:[mcxRate isEqualToString:@"1"] ? kLoginVCID : kHomeVCID];
        } else {
            if ([mcxRate isEqualToString:@"1"]) {
                return [self vcWithID:kMCXRateID];
            } else {
                if ([template isEqualToString:@"2"]) {
                    return [self vcWithID:kGautomHomeVCID];
                } else {
                    return [self vcWithID:kMainActivityID];
                }
            }
        }
    } else {
        if (mobile == nil) {
            //return [self vcWithID:kLoginVCID];
            return [self vcWithID:kMMIHomePanelID];
        } else {
            return [self vcWithID:kMainActivityID];
        }
    }
}

- (UIViewController *)vcWithID:(NSString *)identifier {
    return [self.storyboard instantiateViewControllerWithIdentifier:identifier];
}

@end
