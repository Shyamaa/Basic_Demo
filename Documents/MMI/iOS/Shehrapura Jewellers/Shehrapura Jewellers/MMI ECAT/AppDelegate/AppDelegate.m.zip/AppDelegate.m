//
//  AppDelegate.m
//  AirMobileShop
//
//  Created by MMI SOFTWARE on 06/06/19.
//  Copyright © 2019 MMI Softwares. All rights reserved.
//

#import "AppDelegate.h"
#import "LoginVC.h"
#import "HomeVC.h"
#import "SWRevealViewController.h"
#import "FrontViewController.h"
#import "RearViewController.h"
#import "RightViewController.h"
#import "CustomAnimationController.h"
#import "MainActivity.h"
#import "LoginVC.h"
#import "webUrlconstant.h"
#import "MMIHOMEPanel.h"
#import "LoginVC.h"
#import "Gautom_HomeVC.h"
#import "MCX_RATE.h"
#import <UserNotifications/UserNotifications.h>

@interface AppDelegate ()<SWRevealViewControllerDelegate, UNUserNotificationCenterDelegate>
@property (strong, nonatomic) UIView *blackOverlayView;
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
	// Override point for customization after application launch.
    
    // Listen for screen capture changes (recording or mirroring)
       [[NSNotificationCenter defaultCenter] addObserver:self
                                                selector:@selector(screenCaptureChanged)
                                                    name:UIApplicationUserDidTakeScreenshotNotification
                                                  object:nil];
       
       // Initial check
       //[self updateOverlayForScreenCapture];
    
    [NSThread sleepForTimeInterval:2.0];
    [[UINavigationBar appearance] setBarTintColor:[UIColor colorNamed:@"appRed_Color"]];
    [[UINavigationBar appearance] setTintColor:[UIColor colorWithRed:255/255.0f green:255/255.0f blue:255/255.0f alpha:1.0]];
    [[UINavigationBar appearance] setBackgroundColor:[UIColor colorNamed:@"appRed_Color"]];

    [[UINavigationBar appearance] setTitleTextAttributes:
     [NSDictionary dictionaryWithObjectsAndKeys:
      [UIColor whiteColor],
      NSForegroundColorAttributeName,
      [UIColor whiteColor],
      NSForegroundColorAttributeName,
      [NSValue valueWithUIOffset:UIOffsetMake(0, -1)],
      NSForegroundColorAttributeName,
      [UIFont fontWithName:@"Arial-Regular" size:25.0],
      NSFontAttributeName,
      nil]];
    
    [[UINavigationBar appearance] setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], NSForegroundColorAttributeName, [UIFont fontWithName:@"Helvetica-Neue" size:18.0], NSFontAttributeName, nil]];
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    
    
    UINavigationController *frontNavigationController;
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    webUrlconstant *classA = [webUrlconstant sharedInstance];
    NSString *str_apptype = [classA APPTYPE];
    NSString *str_mcxrate = [classA APPTYPE_MCX];
    

    if ([str_apptype isEqualToString:@"3"]) {
        NSString *savedValue = [[NSUserDefaults standardUserDefaults]stringForKey:@"mobile"];
        if (savedValue == nil) {
            
            if([str_mcxrate isEqualToString:@"1"]){
                LoginVC *frontViewController = [storyboard instantiateViewControllerWithIdentifier:@"LoginVC"];
                
                 frontNavigationController = [[UINavigationController alloc] initWithRootViewController:frontViewController];
            }else{
                HomeVC *frontViewController = [storyboard instantiateViewControllerWithIdentifier:@"HomeVC"];
                
                 frontNavigationController = [[UINavigationController alloc] initWithRootViewController:frontViewController];
            }
            
           
        }else{
            if([str_mcxrate isEqualToString:@"1"]){
                MCX_RATE *frontViewController = [storyboard instantiateViewControllerWithIdentifier:@"MCX_RATE"];
                
                 frontNavigationController = [[UINavigationController alloc] initWithRootViewController:frontViewController];
            }else{
                NSString *strTemplate = [[NSUserDefaults standardUserDefaults]stringForKey:@"template"];
                if([strTemplate isEqualToString:@"2"]){
                    Gautom_HomeVC *frontViewController = [storyboard instantiateViewControllerWithIdentifier:@"Gautom_HomeVC"];
                    frontNavigationController = [[UINavigationController alloc] initWithRootViewController:frontViewController];
                }else{
                    MainActivity *frontViewController = [storyboard instantiateViewControllerWithIdentifier:@"MainActivity"];
                    frontNavigationController = [[UINavigationController alloc] initWithRootViewController:frontViewController];
                }
            }
        }
    }else{
        NSString *savedValue = [[NSUserDefaults standardUserDefaults]stringForKey:@"mobile"];
        if (savedValue == nil) {
            LoginVC *frontViewController = [storyboard instantiateViewControllerWithIdentifier:@"LoginVC"];
            frontNavigationController = [[UINavigationController alloc] initWithRootViewController:frontViewController];
        }else{
            MMIHOMEPanel *frontViewController = [storyboard instantiateViewControllerWithIdentifier:@"MMIHOMEPanel"];
            frontNavigationController = [[UINavigationController alloc] initWithRootViewController:frontViewController];
        }
    }
    RearViewController *rearViewController = [[RearViewController alloc] init];
    UINavigationController *rearNavigationController = [[UINavigationController alloc] initWithRootViewController:rearViewController];
    
    SWRevealViewController *revealController = [[SWRevealViewController alloc] initWithRearViewController:rearNavigationController frontViewController:frontNavigationController];
    revealController.delegate = self;
    
    self.viewController = revealController;
    self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];
    [[self window] setBackgroundColor:[UIColor whiteColor]];

    [self requestPushNotificationPermissions];
    NSDictionary *notification = launchOptions[UIApplicationLaunchOptionsRemoteNotificationKey];
    if (notification) {
        [self handleNotificationData:notification];
    }
    
    return YES;
    
}

- (void)requestPushNotificationPermissions{
    UNUserNotificationCenter *center = [UNUserNotificationCenter currentNotificationCenter];
    center.delegate = self;
    
    UNAuthorizationOptions options = UNAuthorizationOptionAlert | UNAuthorizationOptionSound | UNAuthorizationOptionBadge;
    [center requestAuthorizationWithOptions:options
                          completionHandler:^(BOOL granted, NSError * _Nullable error) {
        if (granted) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [[UIApplication sharedApplication] registerForRemoteNotifications];
            });
        }
    }];
    return;
}

- (void)handleNotificationData:(NSDictionary *)userInfo {
    NSString *arrayflag_redirect=[[userInfo valueForKeyPath:@"aps"] objectForKey:@"flag"];
    NSString *strflag_redirecr;
    strflag_redirecr = [NSString stringWithFormat:@"%@ ",arrayflag_redirect];
    NSCharacterSet *charsTostrFlag= [NSCharacterSet characterSetWithCharactersInString:@"()  \n\""];
    strflag_redirecr = [strflag_redirecr stringByTrimmingCharactersInSet:charsTostrFlag];
    
    if ([strflag_redirecr isEqualToString:@"3"]) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            SWRevealViewController *revealVC = (SWRevealViewController *)self.window.rootViewController;
            if ([revealVC isKindOfClass:[SWRevealViewController class]]) {
                UINavigationController *navController = (UINavigationController *)revealVC.frontViewController;
                UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//                AlertListVC *viewController= [storyboard instantiateViewControllerWithIdentifier:@"AlertListVC"];
//                [navController pushViewController:viewController animated:YES];
                // Add other conditions if needed
            }
        });
    }
}

- (void)userNotificationCenter:(UNUserNotificationCenter *)center
       willPresentNotification:(UNNotification *)notification
         withCompletionHandler:(void (^)(UNNotificationPresentationOptions options))completionHandler {
    completionHandler(UNNotificationPresentationOptionAlert + UNNotificationPresentationOptionSound);
}

#pragma mark: - Pushnotification Method

- (void)application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    if (error.code == 3010) {
        NSLog(@"Push notifications are not supported in the iOS Simulator.");
    } else {
        // show some alert or otherwise handle the failure to register.
        NSLog(@"application:didFailToRegisterForRemoteNotificationsWithError: %@", error);
    }
}
- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings {
    [application registerForRemoteNotifications];
}


- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken{
    NSLog(@"deviceToken: %@", deviceToken);
    // parse token bytes to string
    const char *data = [deviceToken bytes];
    NSMutableString *token = [NSMutableString string];
    for (NSUInteger i = 0; i < [deviceToken length]; i++){
        [token appendFormat:@"%02.2hhX", data[i]];
    }
    // print the token in the console.
    NSLog(@"Push Notification Token: %@", [token copy]);
    
    NSString * devicetoken = [NSString stringWithFormat:@"%@", [token copy]];
    //Format token as you need:
    devicetoken = [devicetoken stringByReplacingOccurrencesOfString:@" " withString:@""];
    devicetoken = [devicetoken stringByReplacingOccurrencesOfString:@">" withString:@""];
    devicetoken = [devicetoken stringByReplacingOccurrencesOfString:@"<" withString:@""];
    [[NSUserDefaults standardUserDefaults] setObject:devicetoken forKey:@"devicetoken"];
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSMutableDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler {
    if(application.applicationState == UIApplicationStateInactive) {
        NSLog(@"Inactive");
        //Show the view with the content of the push
        completionHandler(UIBackgroundFetchResultNewData);
    } else if (application.applicationState == UIApplicationStateBackground) {
        NSLog(@"Background");
        //Refresh the local model
        completionHandler(UIBackgroundFetchResultNewData);
        [NSString stringWithFormat:@"userInfo=%@", userInfo];
        NSLog(@"userInfo=%@", userInfo);
    } else {
        NSLog(@"Active");
        //Show an in-app banner
        completionHandler(UIBackgroundFetchResultNewData);
        [NSString stringWithFormat:@"userInfo=%@", userInfo];
//        NSLog(@"userInfo=%@", userInfo);
    }
    NSString *arrayflag_redirect=[[userInfo valueForKeyPath:@"aps"] objectForKey:@"flag"];
    NSString *strflag_redirecr;
    strflag_redirecr = [NSString stringWithFormat:@"%@ ",arrayflag_redirect];
    NSCharacterSet *charsTostrFlag= [NSCharacterSet characterSetWithCharactersInString:@"()  \n\""];
    strflag_redirecr = [strflag_redirecr stringByTrimmingCharactersInSet:charsTostrFlag];
//    NSLog(@"strflag_redirecr = %@", strflag_redirecr);
    
//    NSString *strPush=strflag_redirecr;
//    NSLog(@"strPush = %@", strPush);
    /*
    if ([strflag_redirecr isEqualToString:@"1"]) {
        NewsroomVC *viewController= [[NewsroomVC alloc]initWithNibName:@"NewsroomVC" bundle:nil];
        viewController.str_notification=@"notification";
        UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:viewController];
        [self.window setRootViewController:navController];
    }else if ([strflag_redirecr isEqualToString:@"3"]) {
        SWRevealViewController *revealVC = (SWRevealViewController *)self.window.rootViewController;
        if ([revealVC isKindOfClass:[SWRevealViewController class]]) {
            UINavigationController *navController = (UINavigationController *)revealVC.frontViewController;
            UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            AlertListVC *viewController= [storyboard instantiateViewControllerWithIdentifier:@"AlertListVC"];
            [navController pushViewController:viewController animated:YES];
        }
    }else{
                UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                HomeVC *viewController= [storyboard instantiateViewControllerWithIdentifier:@"HomeVC"];
                UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:viewController];
                [self.window setRootViewController:navController];
    }
    */
}


- (void)applicationWillResignActive:(UIApplication *)application {
	// Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
	// Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
    //[self showBlackOverlay];
}


- (void)applicationDidEnterBackground:(UIApplication *)application {
	// Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
	// If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}


- (void)applicationWillEnterForeground:(UIApplication *)application {
	// Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
	// Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    // Remove black overlay when app is active
        [self hideBlackOverlay];
}


- (void)applicationWillTerminate:(UIApplication *)application {
	// Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
	// Saves changes in the application's managed object context before the application terminates.
	//[self saveContext];
}


#pragma mark - Core Data stack

@synthesize persistentContainer = _persistentContainer;

- (NSPersistentContainer *)persistentContainer {
    // The persistent container for the application. This implementation creates and returns a container, having loaded the store for the application to it.
    @synchronized (self) {
        if (_persistentContainer == nil) {
            _persistentContainer = [[NSPersistentContainer alloc] initWithName:@"AirMobileShop"];
            [_persistentContainer loadPersistentStoresWithCompletionHandler:^(NSPersistentStoreDescription *storeDescription, NSError *error) {
                if (error != nil) {
                    // Replace this implementation with code to handle the error appropriately.
                    // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                    
                    /*
                     Typical reasons for an error here include:
                     * The parent directory does not exist, cannot be created, or disallows writing.
                     * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                     * The device is out of space.
                     * The store could not be migrated to the current model version.
                     Check the error message to determine what the actual problem was.
                    */
                    NSLog(@"Unresolved error %@, %@", error, error.userInfo);
                    abort();
                }
            }];
        }
    }
    
    return _persistentContainer;
}

#pragma mark - Core Data Saving support

- (void)saveContext {
    NSManagedObjectContext *context = self.persistentContainer.viewContext;
    NSError *error = nil;
    if ([context hasChanges] && ![context save:&error]) {
        // Replace this implementation with code to handle the error appropriately.
        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        NSLog(@"Unresolved error %@, %@", error, error.userInfo);
        abort();
    }
}


#pragma mark - Black Overlay Handling

- (void)screenCaptureChanged {
    // When screen recording or mirroring starts/stops
    [self updateOverlayForScreenCapture];
}

- (void)showBlackOverlay {
    if (!self.blackOverlayView) {
        self.blackOverlayView = [[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
        self.blackOverlayView.backgroundColor = [UIColor blackColor];
        self.blackOverlayView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 300, 100)];
        label.text = @"🚫 Screen capture blocked";
        label.textColor = [UIColor whiteColor];
        label.font = [UIFont boldSystemFontOfSize:20];
        label.textAlignment = NSTextAlignmentCenter;
        label.numberOfLines = 0;
        label.center = self.blackOverlayView.center;
        [self.blackOverlayView addSubview:label];
    }
    
    if (!self.blackOverlayView.superview) {
        [self.window addSubview:self.blackOverlayView];
    }
}

- (void)hideBlackOverlay {
    [self.blackOverlayView removeFromSuperview];
}

- (void)updateOverlayForScreenCapture {
    if ([UIScreen mainScreen].isCaptured) {
        // Screen recording or mirroring active, show black overlay
        [self showBlackOverlay];
    } else {
        // Otherwise hide it
        [self hideBlackOverlay];
    }
}


@end
